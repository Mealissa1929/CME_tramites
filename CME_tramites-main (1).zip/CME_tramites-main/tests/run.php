<?php
// tests/run.php
// Roda todos os testes:  php tests/run.php
// Código de saída 0 = tudo certo; 1 = alguma verificação falhou.

require_once __DIR__ . '/PedidosTest.php';
require_once __DIR__ . '/TrabalhosTest.php';

testarPedidos();
testarTrabalhos();
exit(resumoDosTestes());
