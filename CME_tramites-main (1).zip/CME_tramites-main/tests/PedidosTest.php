<?php
// tests/PedidosTest.php
// Testes do fluxo de pedidos (fluxo/pedidos.json).
// Rodar sozinho:  php tests/PedidosTest.php      (ou todos:  php tests/run.php)
//
// Cada cenário usa um SQLite em memória novo. A recuperação usa um arquivo temporário.

require_once __DIR__ . '/helpers.php';

function testarPedidos(): void
{
    pedidosCaminhoValido();
    pedidosCaminhoInvalido();
    pedidosCancelamento();
    pedidosErroNoDepois();
    pedidosRecuperacao();
}

function pedidosCaminhoValido(): void
{
    grupo('Pedidos: caminho válido (criar, pagar, enviar, entregar)');
    prepararBanco();
    $logs = prepararLogs();

    $id = Estados::criarProcesso('pedidos', ['cliente' => 'Maria', 'valor' => 150]);
    igual('criado', Estados::buscarProcesso($id)['estado'], 'o pedido nasce no estado "criado"');

    $r = Estados::transitar($id, 'pagar');
    verificar($r['sucesso'], 'pagar é aceito');
    igual('pago', $r['estado'], 'estado depois de pagar');

    $dados = Estados::buscarProcesso($id)['dados'];
    verificar(
        isset($dados['data_pagamento'])
            && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $dados['data_pagamento']) === 1,
        'o evento "antes" gravou data_pagamento no processo'
    );
    verificar(
        isset($r['notificacoes'][0]) && strpos($r['notificacoes'][0]['mensagem'], $dados['data_pagamento']) !== false,
        'o evento "depois" usou a data gravada na mensagem'
    );

    $r = Estados::transitar($id, 'enviar');
    igual('enviado', $r['estado'], 'estado depois de enviar');
    igual('notificar', $r['notificacoes'][0]['tipo'], 'enviar gera uma notificação');
    igual("Seu pedido #{$id} foi enviado.", $r['notificacoes'][0]['mensagem'], 'texto da notificação de envio');

    $r = Estados::transitar($id, 'entregar');
    igual('entregue', $r['estado'], 'estado depois de entregar');

    $hist = Registros::listar($id);
    igual(4, count($hist), 'histórico com 4 linhas (criar + 3 ações)');
    igual(['criar', 'pagar', 'enviar', 'entregar'], array_column($hist, 'acao'), 'ações do histórico, em ordem');
    igual([null, 'criado', 'pago', 'enviado'], array_column($hist, 'estado_anterior'), 'estados anteriores do histórico');
    igual(['criado', 'pago', 'enviado', 'entregue'], array_column($hist, 'estado_novo'), 'novos estados do histórico');

    verificar(
        strpos(lerLog($logs, 'eventos.log'), "[NOTIFICACAO] processo #{$id}: Seu pedido #{$id} foi enviado.") !== false,
        'a notificação simulada foi escrita em eventos.log'
    );
    apagarPasta($logs);
}

function pedidosCaminhoInvalido(): void
{
    grupo('Pedidos: caminho inválido (mensagens configuradas)');
    prepararBanco();
    $logs = prepararLogs();

    $id = Estados::criarProcesso('pedidos', ['cliente' => 'João', 'valor' => 150]);

    $r = Estados::transitar($id, 'enviar');
    verificar(!$r['sucesso'], 'enviar sem pagamento é recusado');
    igual('O pedido precisa ter o pagamento confirmado antes de ser enviado.', $r['mensagem'], 'mensagem de enviar sem pagar');
    igual('criado', $r['estado'], 'o estado continua "criado"');

    $r = Estados::transitar($id, 'devolver');
    igual("A ação 'devolver' não é permitida para um pedido 'criado'.", $r['mensagem'], 'ação que não existe usa "acao_invalida"');

    igual(1, count(Registros::listar($id)), 'ações recusadas não gravam histórico');
    igual('criado', Estados::buscarProcesso($id)['estado'], 'ações recusadas não mudam o estado');

    $consulta = Estados::podeTransitar($id, 'enviar');
    verificar(!$consulta['permitido'], 'podeTransitar também recusa enviar sem pagar');
    verificar(Estados::podeTransitar($id, 'pagar')['permitido'], 'podeTransitar aceita pagar');
    igual(1, count(Registros::listar($id)), 'podeTransitar não grava nada');
    igual('criado', Estados::buscarProcesso($id)['estado'], 'podeTransitar não muda o estado');

    $baixo = Estados::criarProcesso('pedidos', ['cliente' => 'Ana', 'valor' => 5]);
    $r = Estados::transitar($baixo, 'pagar');
    verificar(!$r['sucesso'], 'valor abaixo do mínimo impede o pagamento');
    igual('O valor do pedido está abaixo do mínimo.', $r['mensagem'], 'mensagem de valor mínimo');

    $r = Estados::transitar($baixo, 'pagar', ['valor' => 500]);
    verificar(!$r['sucesso'], 'o contexto da ação não sobrescreve o valor gravado do pedido');

    $r = Estados::transitar(9999, 'pagar');
    igual('Processo não encontrado.', $r['mensagem'], 'processo inexistente');
    apagarPasta($logs);
}

function pedidosCancelamento(): void
{
    grupo('Pedidos: cancelamento, aprovação do gerente e estado final');
    prepararBanco();
    $logs = prepararLogs();

    $barato = Estados::criarProcesso('pedidos', ['cliente' => 'Lia', 'valor' => 500]);
    $r = Estados::transitar($barato, 'cancelar');
    verificar($r['sucesso'], 'pedido de R$ 500 cancela sem aprovação');
    igual('cancelado', $r['estado'], 'estado depois de cancelar');
    igual("O pedido #{$barato} foi cancelado.", $r['notificacoes'][0]['mensagem'], 'notificação do cancelamento');

    $caro = Estados::criarProcesso('pedidos', ['cliente' => 'Rui', 'valor' => 5000]);
    $msg = 'Cancelar um pedido acima de R$ 1.000 exige aprovação do gerente.';

    $r = Estados::transitar($caro, 'cancelar');
    igual($msg, $r['mensagem'], 'pedido de R$ 5.000 sem papel é recusado');
    $r = Estados::transitar($caro, 'cancelar', ['papel_usuario' => 'atendente']);
    igual($msg, $r['mensagem'], 'pedido de R$ 5.000 com outro papel é recusado');
    $r = Estados::transitar($caro, 'cancelar', ['valor' => 500]);
    igual($msg, $r['mensagem'], 'não dá para driblar a regra passando outro valor no contexto');
    $r = Estados::transitar($caro, 'cancelar', ['papel_usuario' => 'gerente']);
    verificar($r['sucesso'], 'o gerente cancela o pedido de R$ 5.000');
    verificar(
        !isset(Estados::buscarProcesso($caro)['dados']['papel_usuario']),
        'o papel do usuário é só contexto: não é gravado no processo'
    );

    $pago = Estados::criarProcesso('pedidos', ['cliente' => 'Eva', 'valor' => 3000]);
    Estados::transitar($pago, 'pagar');
    $r = Estados::transitar($pago, 'cancelar');
    igual($msg, $r['mensagem'], 'pedido pago acima de R$ 1.000 também exige o gerente');
    $r = Estados::transitar($pago, 'cancelar', ['papel_usuario' => 'gerente']);
    igual('cancelado', $r['estado'], 'o gerente cancela o pedido pago');

    $r = Estados::transitar($caro, 'pagar');
    verificar(!$r['sucesso'], 'nada sai de um estado final (cancelado)');
    igual("O pedido está 'cancelado' e não pode mais ser alterado.", $r['mensagem'], 'mensagem de estado final');

    $entregue = Estados::criarProcesso('pedidos', ['cliente' => 'Teo', 'valor' => 100]);
    foreach (['pagar', 'enviar', 'entregar'] as $acao) {
        Estados::transitar($entregue, $acao);
    }
    $r = Estados::transitar($entregue, 'cancelar');
    igual("O pedido está 'entregue' e não pode mais ser alterado.", $r['mensagem'], 'pedido entregue também é final');
    apagarPasta($logs);
}

function pedidosErroNoDepois(): void
{
    grupo('Pedidos: erro no evento "depois" é registrado à parte e não desfaz a transição');
    prepararBanco();
    $logs = prepararLogs();

    // Fluxo de teste com um evento "depois" inválido, antes de um válido.
    $dirFluxos = pastaTemporaria('cme_fluxos');
    $fluxo = [
        'estados'        => ['inicio', 'fim'],
        'estados_finais' => ['fim'],
        'transicoes'     => [[
            'de' => 'inicio', 'acao' => 'concluir', 'para' => 'fim',
            'condicoes' => [],
            'antes'     => [],
            'depois'    => [
                ['tipo' => 'enviar_email', 'mensagem' => 'este evento não existe'],
                ['tipo' => 'registrar', 'mensagem' => 'Processo #{id} concluído.'],
            ],
        ]],
        'mensagens' => ['acoes' => [], 'estado_final' => "O processo está '{estado}'."],
    ];
    file_put_contents($dirFluxos . '/teste_depois.json', json_encode($fluxo, JSON_UNESCAPED_UNICODE));
    Estados::$diretorioFluxos = $dirFluxos;

    try {
        $id = Estados::criarProcesso('teste_depois', []);
        $r = Estados::transitar($id, 'concluir');

        verificar($r['sucesso'], 'a transição aconteceu apesar do erro no "depois"');
        igual('fim', $r['estado'], 'estado devolvido');
        igual('fim', Estados::buscarProcesso($id)['estado'], 'o novo estado ficou gravado no banco');
        igual(2, count(Registros::listar($id)), 'o histórico da transição ficou gravado');
        igual(1, count($r['erros_eventos']), 'o erro do evento volta em "erros_eventos"');
        igual('enviar_email', $r['erros_eventos'][0]['tipo'], 'o erro identifica o evento que falhou');
        igual(1, count($r['notificacoes']), 'o evento válido seguinte ainda foi executado');

        verificar(
            strpos(lerLog($logs, 'erros_eventos.log'), "evento 'enviar_email'") !== false,
            'o erro foi gravado à parte, em erros_eventos.log'
        );
        verificar(
            strpos(lerLog($logs, 'eventos.log'), "Processo #{$id} concluído.") !== false,
            'o evento válido foi escrito em eventos.log'
        );
    } finally {
        Estados::$diretorioFluxos = null;
        apagarPasta($dirFluxos);
        apagarPasta($logs);
    }
}

function pedidosRecuperacao(): void
{
    grupo('Pedidos: recuperação (fechar a conexão, abrir de novo, conferir estado e histórico)');
    $logs = prepararLogs();
    $dir = pastaTemporaria('cme_banco');
    $dsn = 'sqlite:' . $dir . '/pedidos.sqlite';

    // "primeira execução do programa"
    prepararBanco($dsn);
    $id = Estados::criarProcesso('pedidos', ['cliente' => 'Maria', 'valor' => 150]);
    Estados::transitar($id, 'pagar');
    Estados::transitar($id, 'enviar');
    Connection::setConnection(null); // encerra: solta a conexão

    // "segunda execução": conexão nova, no mesmo arquivo
    prepararBanco($dsn);
    $p = Estados::buscarProcesso($id);
    verificar($p !== null, 'o processo foi encontrado depois de reabrir o banco');
    igual('enviado', $p['estado'], 'o estado foi recuperado');
    igual(150, $p['dados']['valor'], 'os dados foram recuperados');
    verificar(isset($p['dados']['data_pagamento']), 'a data de pagamento gravada pelo "antes" foi recuperada');
    igual(['criar', 'pagar', 'enviar'], array_column(Registros::listar($id), 'acao'), 'o histórico foi recuperado');

    $r = Estados::transitar($id, 'entregar');
    igual('entregue', $r['estado'], 'o processo recuperado continua o fluxo');
    igual(4, count(Registros::listar($id)), 'o histórico cresceu para 4 linhas');

    Connection::setConnection(null);
    apagarPasta($dir);
    apagarPasta($logs);
}

if (PHP_SAPI === 'cli' && isset($argv[0]) && realpath($argv[0]) === __FILE__) {
    testarPedidos();
    exit(resumoDosTestes());
}
