<?php
// tests/helpers.php
// Apoio aos testes (sem PHPUnit): verificar(), igual(), banco SQLite temporário e pastas temporárias.

require_once __DIR__ . '/../src/Estados.php';

final class Teste
{
    public static int $passou = 0;
    public static array $falhas = [];
}

function grupo(string $titulo): void
{
    echo PHP_EOL . $titulo . PHP_EOL;
}

function verificar(bool $condicao, string $descricao): void
{
    if ($condicao) {
        Teste::$passou++;
        echo "  [ok]     {$descricao}" . PHP_EOL;
    } else {
        Teste::$falhas[] = $descricao;
        echo "  [FALHOU] {$descricao}" . PHP_EOL;
    }
}

function igual($esperado, $obtido, string $descricao): void
{
    if ($esperado === $obtido) {
        verificar(true, $descricao);
        return;
    }
    verificar(
        false,
        $descricao . ' (esperado: ' . var_export($esperado, true) . ', obtido: ' . var_export($obtido, true) . ')'
    );
}

// Abre um SQLite (memória ou arquivo), cria as tabelas se ainda não existirem
// e entrega a conexão ao framework.
function prepararBanco(string $dsn = 'sqlite::memory:'): PDO
{
    $pdo = new PDO($dsn, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');

    $existe = $pdo->query(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'processos'"
    )->fetchColumn();
    if ($existe === false) {
        $pdo->exec(file_get_contents(__DIR__ . '/../database/sqlite.sql'));
    }

    Connection::setConnection($pdo);
    return $pdo;
}

function pastaTemporaria(string $prefixo): string
{
    $dir = sys_get_temp_dir() . '/' . $prefixo . '_' . uniqid();
    mkdir($dir, 0775, true);
    return $dir;
}

function apagarPasta(string $dir): void
{
    foreach (glob($dir . '/*') ?: [] as $item) {
        is_dir($item) ? apagarPasta($item) : @unlink($item);
    }
    @rmdir($dir);
}

// Aponta os logs de eventos para uma pasta temporária (não suja a pasta logs/ do projeto).
function prepararLogs(): string
{
    $dir = pastaTemporaria('cme_logs');
    Eventos::$diretorioLog = $dir;
    return $dir;
}

function lerLog(string $dir, string $arquivo): string
{
    $caminho = $dir . '/' . $arquivo;
    return is_file($caminho) ? (string) file_get_contents($caminho) : '';
}

// Imprime o resumo e devolve o código de saída (0 = tudo certo).
function resumoDosTestes(): int
{
    $falhas = count(Teste::$falhas);
    echo PHP_EOL . str_repeat('-', 50) . PHP_EOL;
    echo 'Verificações que passaram: ' . Teste::$passou . PHP_EOL;
    echo 'Verificações que falharam: ' . $falhas . PHP_EOL;
    foreach (Teste::$falhas as $f) {
        echo "  - {$f}" . PHP_EOL;
    }
    return $falhas === 0 ? 0 : 1;
}
