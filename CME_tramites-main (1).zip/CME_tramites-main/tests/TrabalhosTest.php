<?php
// tests/TrabalhosTest.php
// Testes do fluxo de trabalhos acadêmicos (fluxo/trabalhos.json).
// Rodar sozinho:  php tests/TrabalhosTest.php      (ou todos:  php tests/run.php)

require_once __DIR__ . '/helpers.php';

function testarTrabalhos(): void
{
    trabalhosCaminhoValido();
    trabalhosCaminhoInvalido();
    trabalhosRejeicaoEEstadosFinais();
    trabalhosValidacaoSemBanco();
    trabalhosRecuperacao();
}

function trabalhosCaminhoValido(): void
{
    grupo('Trabalhos: caminho válido (enviar, analisar, aprovar, concluir)');
    prepararBanco();
    $logs = prepararLogs();

    $id = Estados::criarProcesso('trabalhos', [
        'titulo'  => 'Redes de Petri na prática',
        'autor'   => 'Ana',
        'arquivo' => 'trabalho.pdf',
    ]);
    igual('aberto', Estados::buscarProcesso($id)['estado'], 'o trabalho nasce no estado "aberto"');

    $r = Estados::transitar($id, 'enviar');
    igual('em_analise', $r['estado'], 'enviar leva a "em_analise"');
    igual('registrar', $r['notificacoes'][0]['tipo'] ?? null, 'enviar registra uma mensagem');

    $parecer = 'Texto bem estruturado; faltam algumas referências.';
    $r = Estados::transitar($id, 'analisar', [], $parecer);
    verificar($r['sucesso'], 'analisar com parecer é aceito');
    igual('em_analise', $r['estado'], 'analisar mantém o estado "em_analise"');

    $r = Estados::transitar($id, 'aprovar', ['papel_usuario' => 'orientador']);
    igual('aprovado', $r['estado'], 'o orientador aprova');
    igual("Trabalho #{$id} aprovado.", $r['notificacoes'][0]['mensagem'] ?? null, 'notificação da aprovação');

    $r = Estados::transitar($id, 'concluir');
    igual('concluido', $r['estado'], 'concluir leva a "concluido"');

    $dados = Estados::buscarProcesso($id)['dados'];
    verificar(!isset($dados['papel_usuario']), 'o papel do usuário é só contexto: não é gravado');

    $hist = Registros::listar($id);
    igual(5, count($hist), 'histórico com 5 linhas');
    igual(['criar', 'enviar', 'analisar', 'aprovar', 'concluir'], array_column($hist, 'acao'), 'ações do histórico, em ordem');
    igual(
        ['aberto', 'em_analise', 'em_analise', 'aprovado', 'concluido'],
        array_column($hist, 'estado_novo'),
        'novos estados do histórico'
    );
    igual(null, $hist[0]['estado_anterior'], 'a criação não tem estado anterior');
    igual($parecer, $hist[2]['justificativa'], 'a justificativa (parecer) ficou no histórico');
    foreach (['estado_anterior', 'estado_novo', 'data', 'acao', 'justificativa'] as $campo) {
        verificar(array_key_exists($campo, $hist[1]), "o histórico tem o campo \"{$campo}\"");
    }
    apagarPasta($logs);
}

function trabalhosCaminhoInvalido(): void
{
    grupo('Trabalhos: caminho inválido (condições e mensagens)');
    prepararBanco();
    $logs = prepararLogs();

    $semArquivo = Estados::criarProcesso('trabalhos', ['titulo' => 'Sem anexo', 'autor' => 'Bia']);

    $r = Estados::transitar($semArquivo, 'aprovar', ['papel_usuario' => 'orientador']);
    verificar(!$r['sucesso'], 'aprovar um trabalho "aberto" é recusado');
    igual('O trabalho precisa estar em análise para ser aprovado.', $r['mensagem'], 'mensagem de aprovar fora de análise');

    $r = Estados::transitar($semArquivo, 'enviar');
    igual('Anexe o arquivo do trabalho antes de enviar.', $r['mensagem'], 'enviar sem documento é recusado');
    igual('aberto', $r['estado'], 'o estado continua "aberto"');
    igual(1, count(Registros::listar($semArquivo)), 'ações recusadas não gravam histórico');

    $r = Estados::transitar($semArquivo, 'enviar', ['arquivo' => '   ']);
    verificar(!$r['sucesso'], 'um arquivo em branco não conta como documento anexado');

    $r = Estados::transitar($semArquivo, 'enviar', ['arquivo' => 'trabalho_final.pdf']);
    verificar($r['sucesso'], 'o documento informado no contexto da ação libera o envio');

    $msgAprovar = 'Só o orientador pode aprovar o trabalho em análise.';
    $r = Estados::transitar($semArquivo, 'aprovar');
    igual($msgAprovar, $r['mensagem'], 'aprovar sem papel é recusado');
    $r = Estados::transitar($semArquivo, 'aprovar', ['papel_usuario' => 'aluno']);
    igual($msgAprovar, $r['mensagem'], 'aprovar como aluno é recusado');

    $r = Estados::transitar($semArquivo, 'analisar');
    igual('Informe o parecer da análise.', $r['mensagem'], 'analisar sem parecer é recusado');

    $r = Estados::transitar($semArquivo, 'concluir');
    igual('Só é possível concluir um trabalho que já foi aprovado.', $r['mensagem'], 'concluir antes de aprovar');

    igual('em_analise', Estados::buscarProcesso($semArquivo)['estado'], 'depois das recusas o estado segue "em_analise"');
    igual(2, count(Registros::listar($semArquivo)), 'só a criação e o envio válido estão no histórico');
    apagarPasta($logs);
}

function trabalhosRejeicaoEEstadosFinais(): void
{
    grupo('Trabalhos: rejeição com justificativa e estados finais');
    prepararBanco();
    $logs = prepararLogs();

    $id = Estados::criarProcesso('trabalhos', ['titulo' => 'Fora do tema', 'autor' => 'Caio', 'arquivo' => 'caio.pdf']);
    Estados::transitar($id, 'enviar');

    $r = Estados::transitar($id, 'rejeitar');
    igual('Só o orientador pode rejeitar o trabalho em análise.', $r['mensagem'], 'rejeitar sem papel é recusado');

    $r = Estados::transitar($id, 'rejeitar', ['papel_usuario' => 'orientador']);
    igual('Informe a justificativa da rejeição.', $r['mensagem'], 'o orientador não rejeita sem justificativa');
    $r = Estados::transitar($id, 'rejeitar', ['papel_usuario' => 'orientador'], '   ');
    verificar(!$r['sucesso'], 'justificativa em branco também é recusada');
    igual('em_analise', Estados::buscarProcesso($id)['estado'], 'o estado segue "em_analise" depois das recusas');

    $r = Estados::transitar($id, 'rejeitar', ['papel_usuario' => 'orientador'], 'O tema não corresponde à disciplina.');
    verificar($r['sucesso'], 'o orientador rejeita com justificativa');
    igual('rejeitado', $r['estado'], 'estado depois de rejeitar');
    $hist = Registros::listar($id);
    igual('O tema não corresponde à disciplina.', $hist[count($hist) - 1]['justificativa'], 'a justificativa da rejeição ficou no histórico');

    $r = Estados::transitar($id, 'concluir');
    verificar(!$r['sucesso'], 'nada sai de um estado final (rejeitado)');
    igual("O trabalho está 'rejeitado' e não pode mais ser alterado.", $r['mensagem'], 'mensagem de estado final (rejeitado)');
    $r = Estados::transitar($id, 'enviar');
    verificar(!$r['sucesso'], 'um trabalho rejeitado não pode ser reenviado');

    $ok = Estados::criarProcesso('trabalhos', ['titulo' => 'Bom trabalho', 'autor' => 'Dina', 'arquivo' => 'dina.pdf']);
    foreach ([['enviar', []], ['aprovar', ['papel_usuario' => 'orientador']], ['concluir', []]] as [$acao, $ctx]) {
        Estados::transitar($ok, $acao, $ctx);
    }
    $r = Estados::transitar($ok, 'aprovar', ['papel_usuario' => 'orientador']);
    igual("O trabalho está 'concluido' e não pode mais ser alterado.", $r['mensagem'], 'mensagem de estado final (concluído)');
    igual(4, count(Registros::listar($ok)), 'recusas em estado final não gravam histórico');
    apagarPasta($logs);
}

function trabalhosValidacaoSemBanco(): void
{
    grupo('Trabalhos: Validacao::validarTransicao (sem banco de dados)');
    $fluxo = Estados::carregarFluxo('trabalhos');

    $r = Validacao::validarTransicao('em_analise', 'aprovar', ['papel_usuario' => 'orientador'], $fluxo);
    verificar($r['permitido'], 'orientador pode aprovar a partir de "em_analise"');
    igual('aprovado', $r['transicao']['para'], 'a transição encontrada leva a "aprovado"');

    $r = Validacao::validarTransicao('em_analise', 'aprovar', ['papel_usuario' => 'aluno'], $fluxo);
    verificar(!$r['permitido'], 'aluno não pode aprovar');
    igual('Só o orientador pode aprovar o trabalho em análise.', $r['motivo'], 'motivo da recusa');

    $r = Validacao::validarTransicao('concluido', 'enviar', [], $fluxo);
    igual("O trabalho está 'concluido' e não pode mais ser alterado.", $r['motivo'], 'estado final é bloqueado');

    $r = Validacao::validarTransicao('xyz', 'enviar', [], $fluxo);
    verificar(!$r['permitido'], 'estado desconhecido é recusado');
    igual("O estado 'xyz' não existe neste fluxo.", $r['motivo'], 'motivo do estado desconhecido');
}

function trabalhosRecuperacao(): void
{
    grupo('Trabalhos: recuperação (fechar a conexão, abrir de novo, conferir estado e histórico)');
    $logs = prepararLogs();
    $dir = pastaTemporaria('cme_banco');
    $dsn = 'sqlite:' . $dir . '/trabalhos.sqlite';

    // "primeira execução do programa"
    prepararBanco($dsn);
    $id = Estados::criarProcesso('trabalhos', ['titulo' => 'TCC', 'autor' => 'Eli', 'arquivo' => 'tcc.pdf']);
    Estados::transitar($id, 'enviar');
    Estados::transitar($id, 'analisar', [], 'Parecer inicial favorável.');
    Connection::setConnection(null);

    // "segunda execução": conexão nova, no mesmo arquivo
    prepararBanco($dsn);
    $p = Estados::buscarProcesso($id);
    verificar($p !== null, 'o processo foi encontrado depois de reabrir o banco');
    igual('em_analise', $p['estado'], 'o estado foi recuperado');
    igual('TCC', $p['dados']['titulo'], 'os dados foram recuperados');
    $hist = Registros::listar($id);
    igual(['criar', 'enviar', 'analisar'], array_column($hist, 'acao'), 'o histórico foi recuperado');
    igual('Parecer inicial favorável.', $hist[2]['justificativa'], 'a justificativa também foi recuperada');

    $r = Estados::transitar($id, 'aprovar', ['papel_usuario' => 'orientador']);
    igual('aprovado', $r['estado'], 'o processo recuperado continua o fluxo');
    igual(4, count(Registros::listar($id)), 'o histórico cresceu para 4 linhas');

    Connection::setConnection(null);
    apagarPasta($dir);
    apagarPasta($logs);
}

if (PHP_SAPI === 'cli' && isset($argv[0]) && realpath($argv[0]) === __FILE__) {
    testarTrabalhos();
    exit(resumoDosTestes());
}
