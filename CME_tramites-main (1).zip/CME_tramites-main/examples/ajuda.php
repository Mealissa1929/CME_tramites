<?php
// examples/ajuda.php
// Funções de apoio para imprimir as demonstrações (não fazem parte do framework).

require_once __DIR__ . '/../src/Estados.php';

if (PHP_SAPI !== 'cli' && !headers_sent()) {
    header('Content-Type: text/plain; charset=utf-8');
}

function titulo(string $texto): void
{
    echo PHP_EOL . "== {$texto} ==" . PHP_EOL;
}

function mostrarResultado(string $descricao, array $r): void
{
    echo ($r['sucesso'] ? '[OK]   ' : '[ERRO] ') . $descricao . PHP_EOL;
    echo '       ' . $r['mensagem'] . PHP_EOL;
    foreach ($r['notificacoes'] as $n) {
        echo '       ' . strtoupper($n['tipo']) . ': ' . $n['mensagem'] . PHP_EOL;
    }
    foreach ($r['erros_eventos'] as $e) {
        echo '       ERRO NO EVENTO ' . $e['tipo'] . ': ' . $e['erro'] . PHP_EOL;
    }
}

function mostrarProcesso(int $id): void
{
    $p = Estados::buscarProcesso($id);
    echo "Processo #{$id} ({$p['fluxo']}) está '{$p['estado']}'. Dados: "
        . json_encode($p['dados'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
}

function mostrarHistorico(int $id): void
{
    echo "Histórico do processo #{$id}:" . PHP_EOL;
    foreach (Registros::listar($id) as $h) {
        echo '  ' . $h['data'] . ' | ' . ($h['estado_anterior'] ?? '(início)') . ' -> ' . $h['estado_novo']
            . ' | ' . $h['acao'] . ($h['justificativa'] ? ' | ' . $h['justificativa'] : '') . PHP_EOL;
    }
}
