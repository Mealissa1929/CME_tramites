<?php
// examples/pedidos/index.php
// Demonstração do fluxo de pedidos.  Rodar:  php examples/pedidos/index.php
// Usa o banco configurado em util/config.php (padrão: SQLite em arquivo, criado na primeira execução).

require_once __DIR__ . '/../ajuda.php';

titulo('1. Pedido que segue o caminho completo');
$id = Estados::criarProcesso('pedidos', ['cliente' => 'Maria', 'valor' => 150]);
mostrarProcesso($id);
mostrarResultado('enviar antes de pagar', Estados::transitar($id, 'enviar'));
mostrarResultado('pagar', Estados::transitar($id, 'pagar'));
mostrarResultado('enviar', Estados::transitar($id, 'enviar'));
mostrarResultado('entregar', Estados::transitar($id, 'entregar'));
mostrarResultado('cancelar depois de entregue', Estados::transitar($id, 'cancelar'));
mostrarProcesso($id);
mostrarHistorico($id);

titulo('2. Valor abaixo do mínimo');
$barato = Estados::criarProcesso('pedidos', ['cliente' => 'João', 'valor' => 5]);
mostrarResultado('pagar R$ 5', Estados::transitar($barato, 'pagar'));
mostrarHistorico($barato);

titulo('3. Cancelamento acima do limite exige o gerente');
$caro = Estados::criarProcesso('pedidos', ['cliente' => 'Rui', 'valor' => 2500]);
mostrarResultado('cancelar sem aprovação', Estados::transitar($caro, 'cancelar'));
mostrarResultado('cancelar como gerente', Estados::transitar($caro, 'cancelar', ['papel_usuario' => 'gerente']));
mostrarProcesso($caro);
mostrarHistorico($caro);

echo PHP_EOL . 'As notificações simuladas também ficam em logs/eventos.log.' . PHP_EOL;
