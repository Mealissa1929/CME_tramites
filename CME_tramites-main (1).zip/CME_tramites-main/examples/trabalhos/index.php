<?php
// examples/trabalhos/index.php
// Demonstração do fluxo de trabalhos acadêmicos.  Rodar:  php examples/trabalhos/index.php
// Usa o banco configurado em util/config.php (padrão: SQLite em arquivo, criado na primeira execução).

require_once __DIR__ . '/../ajuda.php';

titulo('1. Trabalho aprovado e concluído');
$id = Estados::criarProcesso('trabalhos', ['titulo' => 'Redes de Petri', 'autor' => 'Ana']);
mostrarProcesso($id);
mostrarResultado('enviar sem anexar o arquivo', Estados::transitar($id, 'enviar'));
mostrarResultado('enviar com o arquivo', Estados::transitar($id, 'enviar', ['arquivo' => 'redes_de_petri.pdf']));
mostrarResultado('aprovar como aluno', Estados::transitar($id, 'aprovar', ['papel_usuario' => 'aluno']));
mostrarResultado('analisar sem parecer', Estados::transitar($id, 'analisar'));
mostrarResultado('analisar com parecer', Estados::transitar($id, 'analisar', [], 'Bem estruturado; faltam referências.'));
mostrarResultado('aprovar como orientador', Estados::transitar($id, 'aprovar', ['papel_usuario' => 'orientador']));
mostrarResultado('concluir', Estados::transitar($id, 'concluir'));
mostrarResultado('enviar de novo (estado final)', Estados::transitar($id, 'enviar'));
mostrarHistorico($id);

titulo('2. Trabalho rejeitado (a justificativa é obrigatória)');
$rej = Estados::criarProcesso('trabalhos', ['titulo' => 'Fora do tema', 'autor' => 'Caio', 'arquivo' => 'caio.pdf']);
mostrarResultado('enviar', Estados::transitar($rej, 'enviar'));
mostrarResultado('rejeitar sem justificativa', Estados::transitar($rej, 'rejeitar', ['papel_usuario' => 'orientador']));
mostrarResultado('rejeitar com justificativa', Estados::transitar($rej, 'rejeitar', ['papel_usuario' => 'orientador'], 'O tema não corresponde à disciplina.'));
mostrarProcesso($rej);
mostrarHistorico($rej);

echo PHP_EOL . 'As notificações simuladas também ficam em logs/eventos.log.' . PHP_EOL;
